import os
import sys

# Debugging information
print("Current working directory:", os.getcwd())
print("Contents of current directory:", os.listdir())
print("Python path:", sys.path)
print("Environment variables:", dict(os.environ))

try:
    from src.dynamo_operations import initialize_environments
    print("Successfully imported initialize_environments from src.dynamo_operations")
except ImportError as e:
    print(f"Error importing initialize_environments: {e}")
    print("Contents of src directory:", os.listdir('src') if os.path.exists('src') else "src directory not found")

def lambda_handler(event, context):
    initialize_environments(env_count=5)
    return {
        'statusCode': 200,
        'body': 'Environment initialization complete.'
    }
