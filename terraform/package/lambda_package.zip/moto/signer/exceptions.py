"""Exceptions raised by the signer service."""
